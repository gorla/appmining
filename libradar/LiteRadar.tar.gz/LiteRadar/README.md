# LiteRadar
Lite version of LibRadar


## Usage

```bash
$ python literadar.py someapp.apk
```
View [docs/QuickStart.md](https://github.com/pkumza/LiteRadar/blob/master/docs/QuickStart.md) for more information.
